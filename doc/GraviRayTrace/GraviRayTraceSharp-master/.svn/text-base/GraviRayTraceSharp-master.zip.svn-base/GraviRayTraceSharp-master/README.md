# GraviRayTraceSharp
.NET ray tracer simulating gravitational lensing effect of Kerr black hole.
